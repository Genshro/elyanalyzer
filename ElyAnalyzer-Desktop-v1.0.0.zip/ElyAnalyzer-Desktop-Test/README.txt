ElyAnalyzer Desktop v1.0.0

Installation Instructions:
1. Extract all files to a folder
2. Run tauri-app.exe
3. Both tauri-app.exe and analysis-engine.exe must be in the same folder
